VacuumGantt 1.0

[Kontakt]
info@vacuumlabs.com

[Dependencies]
jQuery		1.10.2
d3js		3.3.5
Moment.js	2.2.1
(plugin je pravdepodobne kompaktibilny
aj so starsimi verziami tychto kniznic)