VacuumGantt 1.1

[changelog]
v1.1
+ pridane tooltipy pre eventy/intervaly (vyzaduje jQuery plugin qTip)

[Kontakt]
info@vacuumlabs.com

[Dependencies]
jQuery		1.10.2
d3js		3.3.5
Moment.js	2.2.1
qTip.js		2.1.1 (builded with Speech bubble 'tips')
imagesLoaded    3.0.2 (volitelne k qTip.js. Potrebne ak sa bude v tooltipoch zobrazovat aj obsah s obrazkami)

(plugin je pravdepodobne kompaktibilny aj so starsimi verziami tychto kniznic)